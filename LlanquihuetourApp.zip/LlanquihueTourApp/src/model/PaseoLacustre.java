package model;

public class PaseoLacustre extends ServicioTuristico {

    private String lago;

    public PaseoLacustre(String nombre, int duracionHoras, String lago) {
        super(nombre, duracionHoras);
        this.lago = lago;
    }

    @Override
    public void mostrarInformacion() {

        System.out.println("===== Paseo Lacustre =====");
        System.out.println("Nombre: " + nombre);
        System.out.println("Duración: " + duracionHoras + " horas");
        System.out.println("Lago: " + lago);
        System.out.println();

    }

}