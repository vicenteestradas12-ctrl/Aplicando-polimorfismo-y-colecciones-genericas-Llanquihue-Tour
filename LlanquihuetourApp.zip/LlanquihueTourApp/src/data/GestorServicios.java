package data;

import java.util.ArrayList;
import java.util.List;

import model.ServicioTuristico;
import model.RutaGastronomica;
import model.PaseoLacustre;
import model.ExcursionCultural;

public class GestorServicios {

    private List<ServicioTuristico> servicios;

    public GestorServicios() {

        servicios = new ArrayList<>();

        servicios.add(new RutaGastronomica(
                "Sabores del Sur", 5, "Comida Alemana"));

        servicios.add(new PaseoLacustre(
                "Navegación Llanquihue", 3, "Lago Llanquihue"));

        servicios.add(new ExcursionCultural(
                "Museo Colonial", 4, "Frutillar"));

        servicios.add(new RutaGastronomica(
                "Ruta del Salmón", 6, "Mariscos"));

        servicios.add(new PaseoLacustre(
                "Puerto Varas en Lancha", 2, "Lago Todos los Santos"));

    }

    public List<ServicioTuristico> getServicios() {
        return servicios;
    }

}